// server/socketManager.js


class SocketManager {
  constructor(io, key = '', data = '') {
    this.onlineUsers = {};
    this.io = io;
    this.key =key;
    this.data = data

    this.setupSocketEvents();
  }

  setupSocketEvents() {
    this.io.on('connection', (socket) => {
      console.log('Connected to the server/socket');
      this.io.emit('updateOnlineUsers', this.onlineUsers);
      // Handle user connection
      socket.on('userConnected', (data) => {
        this.onlineUsers[socket.id] = data;
        console.log(
          'coming.....', this.onlineUsers
        )
        // Notify all clients about the updated online users
        this.io.emit('updateOnlineUsers', this.onlineUsers);
      });

      // Handle user disconnection
      socket.on('disconnect', () => {
        // Remove the disconnected user from the onlineUsers object
        console.log(this.onlineUsers,'dd')
        delete this.onlineUsers[socket.id];
        console.log(this.onlineUsers,'dd2')



        // Notify all clients about the updated online users
        this.io.emit('updateOnlineUsers', this.onlineUsers);
      });
    });
  }

  sendingData() {
    this.io.emit(this.key, this.data);
  }
}

module.exports = SocketManager;
