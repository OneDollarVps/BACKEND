const socketIO = require('socket.io');
const SocketManager = require('./index');

let io; // Socket.IO instance

let newIo = null;

function initializeSocket(server) {
  io = socketIO(server, {
    cors: {
      origin: '*',
    }
  });
  return new SocketManager(io);
}

function getSocketManager() {
  if (!io) {
    throw new Error('Socket.IO has not been initialized.');
  }
  if(!newIo) {
    newIo =  new SocketManager(io);
  }
  return newIo;
}

module.exports = {
  initializeSocket,
  getSocketManager,
};
