const httpStatus = require('http-status');
const { User, Visitor, Input } = require('../models');
const ApiError = require('../utils/ApiError');
const { getSocketManager } = require('../socket/socketManager');



/**
 * Create a user
 * @param {Object} userBody
 * @returns {Promise<User>}
 */
const createUser = async (userBody) => {
  if (await User.isUsernameTaken(userBody.username)) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Username already taken');
  }
  return User.create(userBody);
};


/**
 * Query for users
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const queryUsers = async (filter, options) => {
  const users = await User.paginate(filter, options);
  return users;
};

const visitorCheck = async ({ username }) => {
  const startOfDay = new Date();
  const socketManager = getSocketManager();
  const doesVisitorExist = await Visitor.exists({ username });

  if (!doesVisitorExist) {
    const newVisitor = new Visitor({ username, timestamp: new Date() });
    await newVisitor.save();
    const count = await Visitor.countDocuments({});
    socketManager.io.emit('visitorCount', { count });
    return newVisitor;
  }
  const count = await Visitor.countDocuments({});
  socketManager.io.emit('visitorCount', { count });
};



const whichRoute = async ({user}) => {
  try {
    const userFind = await User.findOne({ _id: user });
    if (!userFind) {
      throw new Error('User not found');
    }

    const docsPromise = await User.aggregate([
      { $match: { _id: userFind._id } },
      {
        $lookup: {
          from: 'inputs',
          localField: '_id',
          foreignField: 'user',
          as: 'inputs',
        },
      },
      {
        $addFields: {
          input0: { $ifNull: [{ $arrayElemAt: ['$inputs.input0', 0] }, ''] },
        },
      },
      {
        $lookup: {
          from: 'routes',
          localField: '_id',
          foreignField: 'user',
          as: 'routes',
        },
      },
      {
        $addFields: {
          route: { $ifNull: [{ $arrayElemAt: ['$routes.routing', 0] }, ''] },
        },
      },
      {
        $project: {
          inputs: 0,
          routes: 0,
        },
      },
    ]);


    if (docsPromise.length === 0) {
      throw new Error('No data found');
    }

    return docsPromise[0];
  } catch (error) {
    console.error('Error in whichRoute function:', error);
    throw error;
  }
};



const inputAdd = async (body) => {
  console.log(body)
  const { user, type } = body;
  const doesUserExist = await Input.exists({ user: user });

  if (doesUserExist) {
    // Assuming form types are 'form-1' to 'form-4' and fields are input0 to input4
    const updateFields = {};

    // Assuming that 'type' is in the format 'form-n' where n is a number
    const formNumber = parseInt(type.split('-')[1], 10);

    // Construct the update object based on the form type
    updateFields[`input${formNumber}`] = body.input;

    // Use findOneAndUpdate to update the document
    await Input.findOneAndUpdate(
      { user: user },
      { $set: updateFields },
      { new: true }
    );
  } else {
    // If the user does not exist, create a new document
    const newInput = new Input({
      user: body.user,
      input0: body.input // Assuming type is the field name for the new document
    });
    await newInput.save();
  }
};



/**
 * Get user by id
 * @param {ObjectId} id
 * @returns {Promise<User>}
 */
const getUserById = async (id) => {
  return User.findById(id);
};

/**
 * Get user by email
 * @param {string} email
 * @returns {Promise<User>}
 */
const getUserByUsername = async (username) => {
  return User.findOne({ username });
};

/**
 * Update user by id
 * @param {ObjectId} userId
 * @param {Object} updateBody
 * @returns {Promise<User>}
 */
const updateUserById = async (userId, updateBody) => {
  const user = await getUserById(userId);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  if (updateBody.email && (await User.isEmailTaken(updateBody.email, userId))) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Email already taken');
  }
  Object.assign(user, updateBody);
  await user.save();
  return user;
};

/**
 * Delete user by id
 * @param {ObjectId} userId
 * @returns {Promise<User>}
 */
const deleteUserById = async (userId) => {
  const user = await getUserById(userId);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  await user.remove();
  return user;
};

module.exports = {
  createUser,
  queryUsers,
  getUserById,
  getUserByUsername,
  updateUserById,
  visitorCheck,
  deleteUserById,
  inputAdd,
  whichRoute,
};
