const express = require('express');
const auth = require('../../middlewares/auth');
const validate = require('../../middlewares/validate');
const userValidation = require('../../validations/user.validation');
const userController = require('../../controllers/user.controller');
const adminController = require('../../controllers/admin.controller');
const imageController = require('../../controllers/image.controller');

const router = express.Router();


router
  .route('/visitor')
  .post( validate(userValidation.visitorCheck), userController.visitorCheck)

  router
  .route('/input')
  .post( validate(userValidation.inputCheck), userController.inputAdd)

  router
  .route('/which-route/:user')
  .get( userController.whichRoute)

  router
  .route('/get-image/:user')
  .get( imageController.showThemImages)

module.exports = router;
