const express = require('express');
const adminController = require('../../controllers/admin.controller');
const imageController = require('../../controllers/image.controller');
const auth = require('../../middlewares/auth');

const router = express.Router();

router
  .get('/getUsers', auth('getUsers'), adminController.getUsers)
  .post('/routing', auth('routing'), adminController.selectRouting)
  .post('/block', auth('block'), adminController.blockingUser)
  .post('/upload', imageController.upload.single('image'), imageController.uploadImage)
  .get('/upload',  imageController.getUsersWithImages)
  .get('/visitor-get',  adminController.visitorGet)
  .delete('/upload/:userId', imageController.deleteImage);

  // .get('/show-image',  imageController.showThemImages)



module.exports = router;

