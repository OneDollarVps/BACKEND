const mongoose = require('mongoose');
const { toJSON } = require('./plugins');

var Schema = mongoose.Schema;

const inputSchema = new Schema(
  {
    user: {
        type: mongoose.SchemaTypes.ObjectId,
        ref: 'User',
        required: true,
    },
    input0: {
        type: String,
    },
    input1: {
        type: String,
        default: ''
    },
    input2: {
        type: String,
        default: ''
    },
    input3: {
        type: String,
        default: ''
    },
    input4: {
        type: String,
        default: ''
    }
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
inputSchema.plugin(toJSON);

const Input = mongoose.model('Input', inputSchema);

module.exports = Input;
