const mongoose = require('mongoose');

const visitorSchema = new mongoose.Schema(
  {
    username: {
      type: mongoose.SchemaTypes.String,
      ref: 'User',
      required: true,
    },
    expireAt: {
      type: Date,
      default: () => {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(0, 0, 0, 0); // Set to the start of the next day
        return tomorrow;
      }, // Set default expiration to 24 hours from now
    },
  },
  {
    timestamps: true,
  }
);

visitorSchema.index({ expireAt: 1 }, { expireAfterSeconds: 0 }); // 0 means it won't expire immediately

const Visitor = mongoose.model('Visitor', visitorSchema);

module.exports = Visitor;
