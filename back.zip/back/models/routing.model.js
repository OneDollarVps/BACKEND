const mongoose = require('mongoose');
const { toJSON } = require('./plugins');

var Schema = mongoose.Schema;

const routingSchema = new Schema(
  {
    routing: {
      type: String,
      required: true,
      default:''
    },
    user: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'User',
      required: true,
    }
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
routingSchema.plugin(toJSON);

const Route = mongoose.model('Route', routingSchema);

module.exports = Route;
