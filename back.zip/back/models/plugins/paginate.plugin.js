/* eslint-disable no-param-reassign */

const paginate = (schema) => {
  schema.statics.paginate = async function (filter, options) {
    let sort = '';
    if (options.sortBy) {
      const sortingCriteria = [];
      options.sortBy.split(',').forEach((sortOption) => {
        const [key, order] = sortOption.split(':');
        sortingCriteria.push((order === 'asc' ? '-' : '') + key);
      });
      sort = sortingCriteria.join(' ');
    } else {
      sort = '-createdAt'; // Sort by createdAt field in descending order by default
    }

    const limit = options.limit && parseInt(options.limit, 10) > 0 ? parseInt(options.limit, 10) : 0;
    const page = options.page && parseInt(options.page, 10) > 0 ? parseInt(options.page, 10) : 0;
    const skip = (page - 1) * limit;

    const countPromise = this.countDocuments(filter).exec();
    let docsPromise = this.aggregate([
      {
        $match: filter,
      },
      {
        $lookup: {
          from: 'images',
          localField: '_id',
          foreignField: 'user',
          as: 'images',
        },
      },
      {
        $addFields: {
          previewImage: { $arrayElemAt: ['$images', 0] }, // Assuming there is only one image
        },
      },
      {
        $lookup: {
          from: 'inputs',
          localField: '_id',
          foreignField: 'user',
          as: 'inputs',
        },
      },
      {
        $addFields: {
          input0: { $arrayElemAt: ['$inputs.input0', 0] },
          input1: { $arrayElemAt: ['$inputs.input1', 0] },
          input2: { $arrayElemAt: ['$inputs.input2', 0] },
          input3: { $arrayElemAt: ['$inputs.input3', 0] },
          input4: { $arrayElemAt: ['$inputs.input4', 0] },
        },
      },
      {
        $lookup: {
          from: 'routes',
          localField: '_id',
          foreignField: 'user',
          as: 'routes',
        },
      },
      {
        $addFields: {
          route: { $arrayElemAt: ['$routes.routing', 0] },
        },
      },
      {
        $project: {
          inputs: 0,
          images: 0,
          routes: 0
        },
      },
      {
        $sort: { createdAt: -1 }, // Sort by createdAt in descending order
      },
    ]);

    if (options.populate) {
      options.populate.split(',').forEach((populateOption) => {
        docsPromise = docsPromise.lookup(
          populateOption
            .split('.')
            .reverse()
            .reduce((a, b) => ({ from: b, localField: a, foreignField: '_id', as: b }))
        );
      });
    }

    docsPromise = docsPromise.exec();

    return Promise.all([countPromise, docsPromise]).then((values) => {
      const [totalResults, results] = values;
      const totalPages = Math.ceil(totalResults / limit);
      const result = {
        results,
        totalResults,
      };
      return Promise.resolve(result);
    });
  };
};

module.exports = paginate;
