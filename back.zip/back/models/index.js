module.exports.User = require('./user.model');
module.exports.Token = require('./token.model')
module.exports.Route = require('./routing.model')
module.exports.Image = require('./image.model')
module.exports.Visitor = require('./visitor.model')
module.exports.Input = require('./input.model')