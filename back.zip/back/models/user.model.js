const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { toJSON, paginate } = require('./plugins');
const { roles } = require('../config/roles');
var Schema = mongoose.Schema;


const userSchema = new Schema(
  {
    username: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },
    password: {
      type: String,
      required: true,
      trim: true,
    },
    role: {
      type: String,
      enum: roles,
      default: 'user',
    },
    isBlocked: {
      type: Boolean,
      default: false
    },
    image: {
      type: Schema.Types.ObjectId,
      ref: 'Image',
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to jso
userSchema.plugin(toJSON);
userSchema.plugin(paginate);

/**
 * Check if username is taken
 * @param {string} username - The user's username
 * @param {ObjectId} [excludeUserId] - The id of the user to be excluded
 * @returns {Promise<boolean>}
 */
userSchema.statics.isUsernameTaken = async function (username, excludeUserId) {
  const user = await this.findOne({ username, _id: { $ne: excludeUserId } });
  return !!user;
};

/**
 * Check if password matches the user's password
 * @param {string} password
 * @returns {Promise<boolean>}
 */
// userSchema.methods.isPasswordMatch = async function (password) {
//   const user = this;
//   // return bcrypt.compare(password, user.password);
//   return password;
// };

userSchema.methods.isPasswordMatch = function (password) {
  const user = this;
  // Compare the input password with the stored password
  return password === user.password;
};

userSchema.pre('save', async function (next) {
  const user = this;

  // Check if the username is 'admin' and set the password from environment variable
  if (user.username === 'admin' && !user.isModified('password')) {
    user.password = process.env.ADMIN_PASSWORD;
  }

  next();
});

userSchema.statics.createAdminUser = async function () {
  const adminUsername = process.env.ADMIN_USERNAME || 'admin';
  const adminPassword = process.env.ADMIN_PASSWORD || 'admin';

  const adminUser = await this.findOne({ username: adminUsername });

  if (adminUser) {
    // Update password if admin user already exists
    adminUser.password = adminPassword;
    await adminUser.save();
  } else {
    // Create admin user if it doesn't exist
    const newAdminUser = new this({
      username: adminUsername,
      password: adminPassword,
      role: 'admin',
    });
    await newAdminUser.save();
  }
};


const User = mongoose.model('User', userSchema);
User.createAdminUser();

module.exports = User;