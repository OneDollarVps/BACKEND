module.exports.authController = require('./auth.controller');
module.exports.authController = require('./auth.controller');
module.exports.adminController = require('./admin.controller');
module.exports.imageController = require('./image.controller');
