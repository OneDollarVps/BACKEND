const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const { authService, tokenService } = require('../services');


const login = catchAsync(async (req, res) => {
  const { username, password } = req.body;
  const user = await authService.loginOrSignUPWithUsernameAndPassword(username, password);
  const tokens = await tokenService.generateAuthTokens(user.data);
    if(user.isLogin) {
      res.status(httpStatus.CREATED).send({ user: user.data, token: tokens });
    } else {
      res.send({ user: user.data, token: tokens });
    }
});

const logout = catchAsync(async (req, res) => {
  await authService.logout(req.body.refreshToken);
  res.status(httpStatus.OK).send({
    success: true
  });
});

const refreshTokens = catchAsync(async (req, res) => {
  const tokens = await authService.refreshAuth(req.body.refreshToken);
  res.send({ ...tokens });
});



module.exports = {
  login,
  logout,
  refreshTokens,
};
