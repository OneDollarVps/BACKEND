const httpStatus = require('http-status');
const multer = require('multer');
const path = require('path');
const { Image, User } = require('../models');
const fs = require('fs').promises;


// Set up multer for handling file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Set your desired upload directory
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}${path.extname(file.originalname)}`;
    cb(null, file.fieldname + '-' + uniqueSuffix);
  },
});

const upload = multer({ storage });


const uploadImage = async (req, res) => {
  try {
    const { userId } = req.body;

    // Check if file is present in the request
    if (!req.file) {
      return res.status(httpStatus.BAD_REQUEST).json({
        success: false,
        message: 'No file uploaded',
      });
    }

    // Find the image with the given userId
    const existingImage = await Image.findOne({ user: userId });

    if (existingImage) {
      // If an existing image is found, delete its file from the upload folder
      await fs.unlink(existingImage.path);

      // Update the existing image properties
      existingImage.filename = req.file.originalname;
      existingImage.path = req.file.path;

      // Save the updated image document
      const updatedImage = await existingImage.save();

      res.status(httpStatus.OK).json({
        success: true,
        data: updatedImage,
      });
    } else {
      // Create a new image document in the database
      const newImage = new Image({
        filename: req.file.originalname,
        path: req.file.path,
        user: userId,
        // Add other fields as needed
      });

      // Save the new image document
      const savedImage = await newImage.save();

      res.status(httpStatus.OK).json({
        success: true,
        data: savedImage,
      });
    }
  } catch (error) {
    console.error(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

const deleteImage = async (req, res) => {

  try {
    const { userId } = req.params;

    // Find the image with the given userId
    const existingImage = await Image.findOne({ user: userId });

    if (existingImage) {
      // Delete the file from the upload folder
      await Image.deleteOne({ _id: existingImage._id });

      await fs.unlink(existingImage.path);

      // Delete the image document from the database

      res.status(httpStatus.OK).json({
        success: true,
        message: 'Image deleted successfully',
      });
    } else {
      res.status(httpStatus.NOT_FOUND).json({
        success: false,
        message: 'Image not found',
      });
    }
  } catch (error) {
    console.error(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

const getUsersWithImages = async (req, res) => {
  try {
    const usersWithImages = await User.aggregate([
      {
        $lookup: {
          from: 'images',
          localField: '_id',
          foreignField: 'user',
          as: 'image'
        }
      }
    ]);
    res.status(httpStatus.OK).json({
      success: true,
      data: usersWithImages,
    });
  } catch (error) {
    console.error(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      success: false,
      message: 'Internal server error',
    });
  }
};


const showThemImages = async (req, res) => {
  try {
    const image = await Image.findOne({user: req.params.user || null});
    res.status(httpStatus.OK).json({
      success: true,
      data: image,
    });
  } catch (error) {
    console.error(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      success: false,
      message: 'Internal server error',
    });
  }
}



module.exports = {
  uploadImage,
  upload,
  showThemImages,
  deleteImage,
  getUsersWithImages
};
