const httpStatus = require('http-status');
const pick = require('../utils/pick');
const catchAsync = require('../utils/catchAsync');
const { userService } = require('../services');
const { User, Route, Visitor } = require('../models');
const { getSocketManager } = require('../socket/socketManager');



const getUsers = catchAsync(async (req, res) => {
  req.query.role = 'user';
  const filter = pick(req.query, ['name', 'role']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  const result = await userService.queryUsers(filter, options);

  res.status(httpStatus.OK).send({
    success: true,
    data: result
  });
});


const visitorGet = catchAsync(async (req, res) => {
  const count = await Visitor.countDocuments({});
  res.status(httpStatus.OK).send({success: true, count});
});

const selectRouting = catchAsync(async (req, res) => {
  const { userId, routing } = req.body;
  const socketManager = getSocketManager();
  // Check if routing is already defined for the user
  const isRoutingDefined = await Route.exists({ user: userId });

  // If routing is defined, update the existing document; otherwise, create a new one
  const routeDoc = isRoutingDefined
    ? await Route.findOneAndUpdate({ user: userId }, { routing }, { new: true })
    : await Route.create({ user: userId, routing });

    socketManager.io.emit('routingChanges', { routing: routeDoc });

  res.status(httpStatus.OK).send({
    success: true,
    data: routeDoc,
  });
});

const blockingUser = catchAsync(async (req, res) => {
  const { userId } = req.body;

  // Find the user document
  const userDoc = await User.findById(userId);

  if (!userDoc) {
    return res.status(httpStatus.NOT_FOUND).send({
      success: false,
      message: 'User not found',
    });
  }

  // Toggle the isBlocked field
  userDoc.isBlocked = !userDoc.isBlocked;

  // Save the updated user document
  const updatedUserDoc = await userDoc.save();

  res.status(httpStatus.OK).send({
    success: true,
    data: updatedUserDoc,
  });
});







module.exports = {
  getUsers,
  selectRouting,
  blockingUser,
  visitorGet
};
