const Joi = require('joi');
const { password } = require('./custom.validation');


const login = {
  body: Joi.object().keys({
    username: Joi.string().required(),
    password: Joi.string().required(),
    role: Joi.string()
  })
};

const logout = {
  body: Joi.object().keys({
    refreshToken: Joi.string().required(),
  }),
};

const refreshTokens = {
  body: Joi.object().keys({
    refreshToken: Joi.string().required(),
  }),
};



module.exports = {
  login,
  logout,
  refreshTokens,
};
