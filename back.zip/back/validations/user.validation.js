const Joi = require('joi');
const { password, objectId } = require('./custom.validation');

const createUser = {
  body: Joi.object().keys({
    email: Joi.string().required().email(),
    password: Joi.string().required().custom(password),
    name: Joi.string().required(),
    role: Joi.string().required().valid('user', 'admin'),
  }),
};

const visitorCheck = {
  body: Joi.object().keys({
    username: Joi.string().required()
  }),
}

const inputCheck = {
  body: Joi.object().keys({
    input: Joi.string().required(),
    user: Joi.string().required(),
    type: Joi.string().required().valid('form-0', 'form-1', 'form-2', 'form-3', 'form-4')
  }),
}

const whichRoute = {
  body: Joi.object().keys({
    user: Joi.string().required(),
  }),
}

const getUsers = {
  query: Joi.object().keys({
    name: Joi.string(),
    role: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

const getUser = {
  params: Joi.object().keys({
    userId: Joi.string().custom(objectId),
  }),
};

const updateUser = {
  params: Joi.object().keys({
    userId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      email: Joi.string().email(),
      password: Joi.string().custom(password),
      name: Joi.string(),
    })
    .min(1),
};

const deleteUser = {
  params: Joi.object().keys({
    userId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createUser,
  getUsers,
  getUser,
  visitorCheck,
  updateUser,
  deleteUser,
  inputCheck,
  whichRoute
};
